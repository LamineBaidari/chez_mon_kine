###################################################################################
#
#    Enablis
#    Copyright (C) 2019
#    Author: Omizuka, Rodolphe_ci & Aziz
#    Company: 
#
###################################################################################
# -*- coding: utf-8 -*-

from odoo import models, fields, api, _

CHAMPS_ADRESSES = ('adresse_rue', 'adresse_ville', 'adresse_pays', 'adresse_postal')

class CmkDispo(models.Model):
    _name = 'cmk.dispo'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    #_inherit = 'res.partner'
    #_rec_name = 'patient'
    _description = 'Patient'
   
    date_hr = fields.Date(string='Date', required=True)
    note = fields.Text()
    suivi_planning = fields.One2many('cmk.planning', 'kine_dispo')
    