###################################################################################
#
#    Enablis
#    Copyright (C) 2019
#    Author: Omizuka, Rodolphe_ci & Aziz
#    Company: 
#
###################################################################################
from odoo import api, models


class res_users(models.Model):
    _inherit = 'res.users'

    @api.model
    def default_get(self, fields_list):
        """This method will invert name when getting default values."""
        result = super(res_users, self).default_get(fields_list)

        inverted = self.env['res.partner']._get_inverse_name(self.env['res.partner']._get_whitespace_cleaned_name(result.get("name", "")), result.get("is_company", False))

        for field in inverted.keys():
            if field in fields_list:
                result[field] = inverted.get(field)

        return result

    @api.multi
    @api.onchange('prenom', 'nom')
    def _compute_name(self):
        """This method will write the 'name' field according to splitted data."""
        for rec in self:
            rec.name = rec.partner_id._get_computed_name(
                rec.nom, rec.prenom)
