###################################################################################
#
#    Enablis
#    Copyright (C) 2019
#    Author: Omizuka, Rodolphe_ci & Aziz
#    Company: 
#
###################################################################################
# -*- coding: utf-8 -*-

from . import res_partner
from . import res_user
from . import cmk_pathologie
from . import cmk_traitement
from . import cmk_patient
from . import cmk_traitementsuspendu
from . import cmk_dispo
from . import cmk_planning
from . import calendar
