###################################################################################
#
#    Enablis
#    Copyright (C) 2019
#    Author: Omizuka, Rodolphe_ci & Aziz
#    Company: 
#
###################################################################################
# from odoo import models, fields

#Separer Nom et prénom
import logging
_logger = logging.getLogger(__name__)
from odoo import api, fields, models, exceptions
#Separer Nom et prénom

class ResPartner(models.Model):
    _inherit = 'res.partner'

    #champ ajouter
    est_patient = fields.Boolean(string='Est un patient', default=False)
    ipm_assurance = fields.Selection( [
        ('ipm', 'IPM'), ('assurance', 'Assurance'), ('autre', 'Autre')
    ], string='Ipm/Assurance')
    #champ ajouter

    #Separer Nom et prénom
    prenom = fields.Char()#firstname
    nom = fields.Char()#lastname
    name = fields.Char(
        compute="_compute_name",
        inverse="_inverse_name_after_cleaning_whitespace",
        required=False,
        store=True)

    @api.model
    def create(self, vals):
        """Override method to invert name at creation if unavailable."""
        context = dict(self.env.context)
        name = vals.get("name", context.get("default_name"))

        if name is not None:
            # Calculate the splitted fields
            inverted = self._get_inverse_name(
                self._get_whitespace_cleaned_name(name),
                vals.get("is_company",
                         self.default_get(["is_company"])["is_company"]))

            for key, value in inverted.items():
                if not vals.get(key) or context.get("copy"):
                    vals[key] = value

            # Remove the combined fields
            if "name" in vals:
                del vals["name"]
            if "default_name" in context:
                del context["default_name"]

        return super(ResPartner, self.with_context(context)).create(vals)

    @api.multi
    def copy(self, default=None):
        """Override method to ensure partners are copied correctly."""
        return super(ResPartner, self.with_context(copy=True)).copy(default)

    @api.model
    def default_get(self, fields_list):
        """This method will invert `name` when getting default values."""
        result = super(ResPartner, self).default_get(fields_list)

        inverted = self._get_inverse_name(
            self._get_whitespace_cleaned_name(result.get("name", "")),
            result.get("is_company", False))

        for field in inverted.keys():
            if field in fields_list:
                result[field] = inverted.get(field)

        return result

    @api.model
    def _get_computed_name(self, nom, prenom):
        """This method will compute the `name` from first and last names."""
        return u" ".join((p for p in (nom, prenom) if p))

    @api.one
    @api.depends("prenom", "nom")
    def _compute_name(self):
        """This method will re-compute and write the `name` field when it changes."""
        self.name = self._get_computed_name(self.nom, self.prenom)

    @api.one
    def _inverse_name_after_cleaning_whitespace(self):
        # Remove unneeded whitespace
        clean = self._get_whitespace_cleaned_name(self.name)

        # Clean name avoiding infinite recursion
        if self.name != clean:
            self.name = clean

        # Save name in the real fields
        else:
            self._inverse_name()

    @api.model
    def _get_whitespace_cleaned_name(self, name):
        return u" ".join(name.split(None)) if name else name

    @api.model
    def _get_inverse_name(self, name, is_company=False):
        """ This method will compute the inverted name."""
        # Company name goes to the nom
        if is_company or not name:
            parts = [name or False, False]
        # Guess name splitting
        else:
            parts = name.strip().split(" ", 1)
            while len(parts) < 2:
                parts.append(False)
        return {"nom": parts[0], "prenom": parts[1]}

    @api.one
    def _inverse_name(self):
        """Try to revert the effect of :meth:`._compute_name`."""
        parts = self._get_inverse_name(self.name, self.is_company)
        self.nom, self.prenom = parts["nom"], parts["prenom"]

    @api.one
    @api.constrains("prenom", "nom")
    def _check_name(self):
        if ((self.type == 'contact' or self.is_company) and
                not (self.prenom or self.nom)):
            raise exceptions.UserError('Missing Last or First Name')

    @api.multi
    @api.onchange("prenom", "nom")
    def _onchange_subnames(self):
        # Modify self's context without creating a new Environment.
        self.env.context = self.with_context(skip_onchange=True).env.context

    @api.multi
    @api.onchange("name")
    def _onchange_name(self):
        if self.env.context.get("skip_onchange"):
            # Do not skip next onchange
            self.env.context = (
                self.with_context(skip_onchange=False).env.context)
        else:
            self._inverse_name_after_cleaning_whitespace()

    @api.model
    def _install_partner_prenom(self):
        # Find records with empty prenom and nom
        records = self.search([("prenom", "=", False),
                               ("nom", "=", False)])

        # Force calculations there
        records._inverse_name()
        _logger.info("%d partners updated installing module.", len(records))

    _sql_constraints = [('check_name', "CHECK( 1=1 )", 'Missing name')]
    #Separer Nom et prénom
