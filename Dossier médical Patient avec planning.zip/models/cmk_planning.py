###################################################################################
#
#    Enablis
#    Copyright (C) 2019
#    Author: Omizuka, Rodolphe_ci & Aziz
#    Company: 
#
###################################################################################
# -*- coding: utf-8 -*-

from odoo import models, fields

class CmkPlanning(models.Model):
    _name = 'cmk.planning'
    #_inherit = ['mail.thread', 'mail.activity.mixin']
    
    id = fields.Integer(string='ID Fiche')
    heure = fields.Selection([
        ('8h-9h', '8H-9H'),
        ('9h-10h', '9H-10H'),
        ('10h-11h', '10H-11H'),
        ('11h-12h', '11H-12H'),
        ('12h-13h', '12H-13H'),
        ('13h-14h', '13H-14H'),
        ('14h-15h', '14H-15H'),
        ('15h-16h', '15H-16H'),
        ('16h-17h', '16H-17H'),
        ('17h-18h', '17H-18H'),
    ], string='Heure')
    kine1 = fields.Many2one('calendar.event', string='Veronique')
    kine2 = fields.Many2one('calendar.event', string='M.Ajavon') 
    kine3 = fields.Many2one('calendar.event', string='O.Fall')
    kine4= fields.Many2one('calendar.event', string='Marie')
    kine5 = fields.Many2one('calendar.event', string='Amy')
    kine6 = fields.Many2one('calendar.event', string='A.Fall')
    kine7 = fields.Many2one('calendar.event', string='A.Mendy')
    kine8 = fields.Many2one('calendar.event', string='Nabou')
    kine9 = fields.Many2one('calendar.event', string='P.Sow')
    kine10 = fields.Many2one('calendar.event', string='Kiné_Resp')


    kine_dispo = fields.Many2one('cmk.dispo', string="dispo") 