###################################################################################
#
#    Enablis - Carrefour
#    Copyright (C) 2019
#    Author: Omizuka, Rodolphe_ci & Aziz
#    Company:
#
###################################################################################
# -*- coding: utf-8 -*-
{
    'name': "Patient",
    'summary': """Module de gestion des patients""",
    'description': """
        Ce module est le module principal de Chez Mon Kiné.
        Il permettra la gestion des patients, des kiné et des rendez-vous.
    """,
    'author': "Omizuka, Rodolphe_ci & Aziz",
    # 'license': "AGPL-3",
    'maintainer': "Omizuka, Rodolphe_ci & Aziz",
    # 'website': "http://www.yourcompany.com",
    'category': 'Enablis',
    'version': '0.1',
    'depends': ['base', 'hr', 'calendar', 'account', 'mail'],
    'data': [
        'security/cmk_security.xml',
        'security/ir.model.access.csv',
        'views/res_partner.xml',
        'views/res_user.xml',
        'views/cmk_patient_vue.xml',
        'views/cmk_dispo.xml',
        'views/planning.xml',
        'views/pathologies.xml',
    ],
    'application': True,
    'auto_install': False,
    'installable': True,
    'images': ['static/icon.png'],

}
