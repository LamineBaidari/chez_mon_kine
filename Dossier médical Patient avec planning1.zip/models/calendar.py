###################################################################################
#
#    Enablis
#    Copyright (C) 2019
#    Author: Omizuka, Rodolphe_ci & Aziz
#    Company: 
#
###################################################################################
# -*- coding: utf-8 -*-

from odoo import api, fields, models


class CalendarEvent(models.Model):
    _inherit = 'calendar.event'