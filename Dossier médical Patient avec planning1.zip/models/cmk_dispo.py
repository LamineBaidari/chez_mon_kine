###################################################################################
#
#    Enablis
#    Copyright (C) 2019
#    Author: Omizuka, Rodolphe_ci & Aziz
#    Company: 
#
###################################################################################
# -*- coding: utf-8 -*-

from ast import literal_eval
from dateutil.relativedelta import relativedelta
from odoo import models, fields, api, _

CHAMPS_ADRESSES = ('adresse_rue', 'adresse_ville', 'adresse_pays', 'adresse_postal')

class CmkDispo(models.Model):
    _name = 'cmk.dispo'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    #_inherit = 'res.partner'
    #_rec_name = 'patient'
    _description = 'Planning patients'

    @api.model
    def _get_default_suivi_planning(self):
        return [
            (0, 0, {'heure': '0'}),
            (0, 0, {'heure': '1'}),
            (0, 0, {'heure': '2'}),
            (0, 0, {'heure': '3'}),
            (0, 0, {'heure': '4'}),
            (0, 0, {'heure': '5'}),
            (0, 0, {'heure': '6'}),
            (0, 0, {'heure': '7'}),
            (0, 0, {'heure': '8'}),
            (0, 0, {'heure': '9'})
        ]
    id = fields.Integer()
    name = fields.Integer(compute='_get_id', readonly=True)
    date_hr = fields.Date(string='Date', required=True)
    note = fields.Text()
    suivi_planning = fields.One2many('cmk.planning', 'kine_dispo', scopy=True, default=_get_default_suivi_planning)
    
    def _get_id(self):
        for record in self:
            if record.id:
                record.name = record.id
                