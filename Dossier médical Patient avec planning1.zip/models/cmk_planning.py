# -*- coding: utf-8 -*-

from odoo import models, fields

class CmkPlanning(models.Model):
    _name = 'cmk.planning'
    #_inherit = ['mail.thread', 'mail.activity.mixin']
    # _inherit = 'calendar.event'
    
    id = fields.Integer(string='ID_Fiche')
    heure = fields.Selection([
        ('0', '8H-9H'),
        ('1', '9H-10H'),
        ('2', '10H-11H'),
        ('3', '11H-12H'),
        ('4', '12H-13H'),
        ('5', '13H-14H'),
        ('6', '14H-15H'),
        ('7', '15H-16H'),
        ('8', '16H-17H'),
        ('9', '17H-18H')
    ], string='Heure')
    kine1 = fields.Many2one('calendar.event', string='Veronique')
    kine2 = fields.Many2one('calendar.event', string='M.Ajavon') 
    kine3 = fields.Many2one('calendar.event', string='O.Fall')
    kine4= fields.Many2one('calendar.event', string='Marie')
    kine5 = fields.Many2one('calendar.event', string='Amy')
    kine6 = fields.Many2one('calendar.event', string='A.Fall')
    kine7 = fields.Many2one('calendar.event', string='A.Mendy')
    kine8 = fields.Many2one('calendar.event', string='Nabou')
    kine9 = fields.Many2one('calendar.event', string='P.Sow')
    kine10 = fields.Many2one('calendar.event', string='Kiné_Resp')


    kine_dispo = fields.Many2one('cmk.dispo', string="dispo") 